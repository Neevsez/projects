from PyQt5 import QtWidgets, QtCore, QtGui, Qt
from Form import *
import sys
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import cv2
import numpy as np
from SpectrC4 import *


class ThreadOpenCV(Qt.QThread):
    changePixmap = Qt.pyqtSignal(Qt.QImage)

    def __init__(self):
        super().__init__()

    def run(self):
        cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
        cap.set(cv2.CAP_PROP_FPS, 24)

        while True:
            ret, frame = cap.read()
            if ret:
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frame_expanded = np.expand_dims(frame_rgb, axis=0)
                rgbImage = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                h, w, ch = rgbImage.shape
                convertToQtFormat = Qt.QImage(
                    rgbImage.data, w, h, ch * w, Qt.QImage.Format_RGB888)
                p = convertToQtFormat.scaled(881, 301, Qt.Qt.KeepAspectRatio)
                self.changePixmap.emit(p)

                if cv2.waitKey(1) == ord('q'):
                    break
            cv2.destroyAllWindows()


class Window(QtWidgets.QMainWindow, Ui_Form):
    def __init__(self, dangl):
        super().__init__()
        self.setupUi(self)
        self.dangl = dangl

        self.show_graph.clicked.connect(self.graph)  # кнопка графика
        self.set_values.clicked.connect(self.data)  # кнопка вводимых данных
        self.simulation.clicked.connect(self.camera)  # кнопка камеры

        # -- камера --
        self.thread = ThreadOpenCV()
        self.thread.changePixmap.connect(self.setImage)

        # -- график --
        self.scene = QtWidgets.QGraphicsScene()
        self.graphicsView.setScene(self.scene)

        self.figure = Figure()
        self.axes = self.figure.gca()
        self.axes.set_title("plot")

    # -- функция записи вводимых данных --
    def data(self):
        self.d = [
            float(self.ax_input.text()),
            float(self.ay_input.text()),
            float(self.df_input.text()),
            float(self.dfp_input.text()),
            float(self.initial_angle_input.text()),
            float(self.end_angle_input.text()),
        ]
        self.t = Test(self.dangl, self.d[0], self.d[1], self.d[4], self.d[5])
        self.k, self.v = self.t.calculate()
        self.table_flag = bool(self.table_center_check.checkState()) # проверка выравнивания стола по центру
        self.prism_flag = bool(self.prism_center_check.checkState()) # проверка выставления призмы в нормальное положение

    # -- функция камеры --
    def camera(self):
        self.thread.start()

    def setImage(self, image):
        self.label_video.setPixmap(Qt.QPixmap.fromImage(image))

    # -- функция построения графика --
    def graph(self):
        self.axes.clear()
        self.axes.plot(self.k, self.v)

        self.axes.legend()
        self.axes.grid(True)

        self.canvas = FigureCanvas(self.figure)
        self.proxy_widget = self.scene.addWidget(self.canvas)

# -- основные действия программы --


class Programm:
    def __init__(self, dangl):
        self.app = QtWidgets.QApplication(sys.argv)
        self.window = Window(dangl)
        self.window.show()
        sys.exit(self.app.exec_())
# -- программа --


def Main():
    dangl = 0.0483
    Programm(dangl)


# -- начало выполнения программы --
if __name__ == "__main__":
    Main()
