import csv
import pyfirmata as pf
import time as t
import cv2
from threading import Thread
from matplotlib import pyplot as pt


class Test:
    def __init__(self, dangl, ax, ay, fii, fif):
        self.dangl = dangl
        self.flag = True
        self.ax = ax
        self.ay = ay
        self.fii = fii / self.dangl
        self.fif = fif / self.dangl

    def __start__(self):
        self.a = pf.Arduino("COM5")
        self.it = pf.util.Iterator(self.a)
        self.it.start()
        print("Подлюченно")

        self.p = [
            self.a.get_pin('d:3:o'),
            self.a.get_pin('d:2:o'),  # p1, p2 - y-трансляция стола
            self.a.get_pin('d:5:o'),
            self.a.get_pin('d:4:o'),  # p5, p6 - х-трансляция стола
            self.a.get_pin('d:6:o'),
            self.a.get_pin('d:7:o'),  # p7, p8 - вращение стола
            self.a.get_pin('d:8:o'),
            self.a.get_pin('d:9:o'),  # p9, p10 - вращение фотоприемника
        ]

        self.a0 = self.a.get_pin('a:0:i')  # фотоприемник №1
        self.a1 = self.a.get_pin('a:1:i')  # фотоприемник №2

        for i in range(len(self.p)):
            self.p[i].write(1)

        return self.p, self.a0, self.a1

    def calculate(self):
        self.x = []
        self.y = []
        self.p, self.a0, self.a1 = self.__start__()
        self.fi = 0
        self.j = 0
        while self.flag:
            print(f"\n ax = {self.ax}, \t ay = {self.ay}, \n fii = {self.fii}, \t fif = {self.fif}\n")

            if self.ax > 0:
                self.n = 0
                while self.ax > self.n:
                    self.p[3].write(1)
                    self.p[2].write(1)
                    self.p[2].write(0)
                    self.n += 1
                    print(f'x= {self.n}')

            if self.ax < 0:
                self.n = 0
                while self.ax < self.n:
                    self.p[3].write(0)
                    self.p[2].write(0)
                    self.p[2].write(1)
                    self.n -= 1
                    print(f'x= {self.n}')

            if self.ay > 0:
                self.n = 0
                while self.ay > self.n:
                    self.p[1].write(1)
                    self.p[0].write(1)
                    self.p[0].write(0)
                    self.n += 1
                    print(f'y= {self.n}')

            if self.ay < 0:
                self.n = 0
                while self.ay < self.n:
                    self.p[1].write(0)
                    self.p[0].write(0)
                    self.p[0].write(1)
                    self.n -= 1
                    print(f'y= {self.n}')

            with open("SpectrС.csv", "w+") as fs:
                self.w = csv.writer(fs)
                self.n = 0
                if self.fii < 0:
                    while self.fii <= self.n:
                        self.p[5].write(1)
                        self.n -= 1
                        self.p[4].write(1)
                        self.p[4].write(0)
                        self.p[7].write(0)
                        self.p[6].write(1)
                        self.p[6].write(0)
                        self.p[6].write(1)
                        self.p[6].write(0)

                if self.fii > 0:
                    while self.fii >= self.n:
                        self.p[5].write(0)
                        self.n += 1
                        self.p[4].write(0)
                        self.p[4].write(1)
                        self.p[7].write(1)
                        self.p[6].write(1)
                        self.p[6].write(0)
                        self.p[6].write(1)
                        self.p[6].write(0)
                print(f"\nfi = {self.n},\tfii = {self.fii},\tfif = {self.fif}\n")

                while self.fif >= self.fi:
                    self.p[5].write(0)
                    self.row = (self.fi * self.dangl, self.a0.read() / self.a1.read())
                    self.w.writerow(self.row)
                    self.x.append(self.row[0])
                    self.y.append(self.row[1])
                    print(self.j, self.row)
                    t.sleep(0.2)
                    self.p[7].write(0)
                    self.p[6].write(1)
                    self.p[6].write(0)
                    self.j += 1

                    self.p[6].write(1)
                    self.p[6].write(0)
                    self.j += 1

                    self.p[4].write(1)
                    self.p[4].write(0)
                    self.fi += 1

                while self.fi > 0:
                    self.p[5].write(1)
                    self.p[4].write(0)
                    self.p[4].write(1)
                    self.fi -= 1

                while self.j > 0:
                    self.p[7].write(1)
                    self.p[6].write(1)
                    self.p[6].write(0)
                    self.j -= 1
                    if self.j == 0:
                        self.flag = False
        return self.x, self.y